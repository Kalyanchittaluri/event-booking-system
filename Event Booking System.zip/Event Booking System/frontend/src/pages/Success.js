export default function Success() {
  return (
    <div style={{ textAlign: "center", marginTop: "80px", fontSize: "24px" }}>
      🎉 Payment Successful!<br />
      Your ticket has been booked.
    </div>
  );
}
